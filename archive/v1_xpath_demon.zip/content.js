// Function to get XPath for an element
function getElementXPath(element) {
  if (element.id !== '')
    return 'id("' + element.id + '")';
  if (element === document.body)
    return element.tagName;

  let ix = 0;
  const siblings = element.parentNode.childNodes;
  for (let i = 0; i < siblings.length; i++) {
    const sibling = siblings[i];
    if (sibling === element)
      return getElementXPath(element.parentNode) + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
    if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
      ix++;
  }
}

// Event listeners for recording actions with coordinates and browser resolution
document.addEventListener('click', (event) => {
  const xpath = getElementXPath(event.target);
  const x = event.clientX; // X-coordinate
  const y = event.clientY; // Y-coordinate
  const resolutionWidth = window.innerWidth; // Browser width
  const resolutionHeight = window.innerHeight; // Browser height

  chrome.runtime.sendMessage({
    action: 'recordAction',
    actionText: `click|${xpath}|${x},${y}|${resolutionWidth}x${resolutionHeight}`
  });
});

document.addEventListener('submit', (event) => {
  const xpath = getElementXPath(event.target);

  chrome.runtime.sendMessage({
    action: 'recordAction',
    actionText: `submit|${xpath}`
  });
});

document.addEventListener('input', (event) => {
  const xpath = getElementXPath(event.target);
  const value = event.target.value;
  const type = event.target.type;

  if (type === 'text' || type === 'textarea' || type === 'email' || type === 'password') {
    chrome.runtime.sendMessage({
      action: 'recordAction',
      actionText: `input|${xpath}|${value}`
    });
  }
});
