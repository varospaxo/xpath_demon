function getFullElementXPath(element) {
    // Return ID path if the element has a unique ID
    if (element.id !== '') {
        return `id("${element.id}")`;
    }

    // Base case: Return /html if the root element is reached
    if (element.tagName.toLowerCase() === 'html') {
        return '/html';
    }

    // Determine the element's position among siblings of the same type
    let position = 1;
    let currentSibling = element;
    while (currentSibling = currentSibling.previousElementSibling) {
        if (currentSibling.tagName === element.tagName) {
            position++;
        }
    }

    // Recursively build the XPath
    let path = '';
    if (element.parentNode) {
        path = getFullElementXPath(element.parentNode) + '/' + element.tagName.toLowerCase();

        // Add position index if the element has siblings of the same type
        const siblings = element.parentNode.children;
        let hasSameTypeSiblings = false;
        for (let sibling of siblings) {
            if (sibling !== element && sibling.tagName === element.tagName) {
                hasSameTypeSiblings = true;
                break;
            }
        }

        if (hasSameTypeSiblings) {
            path += `[${position}]`;
        }
    } else {
        path = '/' + element.tagName.toLowerCase();
    }

    return path;
}

// Capture click events
document.addEventListener('click', (event) => {
    const xpath = getFullElementXPath(event.target);
    const x = event.clientX;
    const y = event.clientY;
    const resolutionWidth = window.innerWidth;
    const resolutionHeight = window.innerHeight;

    console.log(`Click event captured: ${xpath}`); // Debugging log
    chrome.runtime.sendMessage({
        action: 'recordAction',
        actionText: `click|${xpath}|${x},${y}|${resolutionWidth}x${resolutionHeight}`
    });
});

// Capture form submissions
document.addEventListener('submit', (event) => {
    const xpath = getFullElementXPath(event.target);
    console.log(`Submit event captured: ${xpath}`); // Debugging log
    chrome.runtime.sendMessage({
        action: 'recordAction',
        actionText: `submit|${xpath}`
    });
});

// Capture input changes
document.addEventListener('input', (event) => {
    const xpath = getFullElementXPath(event.target);
    const value = event.target.value;
    const type = event.target.type;

    if (type === 'text' || type === 'textarea' || type === 'email' || type === 'password') {
        console.log(`Input event captured: ${xpath}`); // Debugging log
        chrome.runtime.sendMessage({
            action: 'recordAction',
            actionText: `input|${xpath}|${value}`
        });
    }
});
