v1 - records xpath
v2 - records xpath + xy axis + viewport size