v1 - records xpath
v2 - records xpath + xy axis + viewport size
v3 - can identify and record clicks on complex elements like cards.